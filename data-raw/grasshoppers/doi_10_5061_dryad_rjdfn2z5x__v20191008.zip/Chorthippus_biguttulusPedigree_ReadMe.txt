The comma separated file is a pedigree file containing parental information of individuals of Chorthippus biguttulus. Each row is a separate individual.

id = Unique identifier for individuals used in the study starting with the parents. IDs starting with "BM" denote the mothers, "BHSF" denote the fathers. 
dam = Identifier for mothers of the individuals.
sire = Identifiers for fathers of the individuals. 
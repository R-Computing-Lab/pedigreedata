The comma separated file contains information on individual identities, sex, cohort, trait measurements, eggpod identities, nymphal cage identities and maternal identities of Chorthippus bigguttulus used in the study. Each row represents a single individual.


IndID = Identifier for adults used in the study.
Sex = Sex of the individuals, F = female and M = male.
Side = Identifier for left and right sides coded as -0.5 for left and 0.5 for right.
Cohort = Cohort to which individuals belonged [1-5].
MaleFemur = Length of femur of males in mm.
FemaleFemur = Length of femur of females in mm.
MaleWing = Length of hind wing of males in mm.
FemaleWing = Length of hind wing of females in mm.
MaleAntenna = Length of antenna of males in mm.
FemaleAntenna = Length of antenna of females in mm.
MaleLobe = Height of pronotal lobes in males in mm.
FemaleLobe = Height of pronotal lobes in females in mm.
MaleEye = Height of eye in males in mm.
FemaleEye = Height of eye in females in mm.
EggDishID = Identifier of eggpod from which each individual emerged. 
NymphCageID = Identifier of nymphal cages where individuals emerging from the same eggpod were kept. 
MotherID = Identifier for mothers of the individuals used in the study.



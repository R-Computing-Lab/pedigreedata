The comma separated file is a pedigree file containing parental information of individuals of Gomphocerippus rufus. Each row is a separate individual.

id = Unique identifier for individuals used in the study starting with the parents. IDs starting with "RM" denote the mothers, "RHSF" denote the fathers. 
dam = Identifier for mothers of the individuals.
sire = Identifiers for fathers of the individuals. 